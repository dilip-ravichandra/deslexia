"""Download ASSET evaluation data; no inference or cloud compute."""
import json
import urllib.request
from pathlib import Path
from datasets import load_dataset

def main():
    with urllib.request.urlopen("https://huggingface.co/api/datasets/facebook/asset", timeout=30) as response:
        revision = json.load(response)["sha"]
    data = load_dataset("facebook/asset", "simplification", revision=revision)
    target = Path("DATA") / "asset_evaluation"
    target.mkdir(parents=True, exist_ok=True)
    for split, expected in [("validation", 2000), ("test", 359)]:
        if len(data[split]) != expected:
            raise RuntimeError("Dataset count changed; inspect before proceeding")
        path = target / (split + ".jsonl")
        if path.exists():
            raise FileExistsError(str(path) + " already exists; move it before downloading again")
        with path.open("w", encoding="utf-8") as output:
            for row in data[split]:
                output.write(json.dumps(dict(row), ensure_ascii=False) + "\n")
        print("Saved", path, len(data[split]), "examples")
    (target / "provenance.json").write_text(json.dumps({"repository":"facebook/asset", "revision":revision, "configuration":"simplification", "license":"CC-BY-SA-4.0", "purpose":"evaluation, not support-category training", "attribution":"Alva-Manchego et al. (2020), ASSET", "source_url":"https://huggingface.co/datasets/facebook/asset"}, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
