# Your first annotation task

You have already opened the website. Now learn annotation using five examples.

Annotation means choosing what help would fit a selected piece of text.
- VOCABULARY: explain a word.
- SYNTACTIC: restructure a sentence.
- CONCEPTUAL: explain the idea using steps or an example.
- OTHER_UNCERTAIN: missing context, mixed needs, or no clear choice.

Open five_practice_examples.json in VS Code. Read one example at a time.
The suggestions are AI drafts. You may disagree. Fill your_category, your_confidence (1–5), and your_reason (one short sentence). This file is a learning exercise, not an import-ready gold training file. There are four real ASSET source sentences and one clearly marked synthetic example. No human labels have been invented.

Example 1 can need sentence restructuring because directions interrupt a long list. If you only selected “Adjacent”, a vocabulary label could fit instead. The selected span and context determine the decision.
Example 2 can need word definitions: inscription means writing engraved or written on something; attests means provides evidence for. Do not invent what the drum refers to.
Example 3 lacks the context needed to know who “They” are. Uncertain is a valid choice.
Example 4 can need the word cultivation explained as growing a crop.
Example 5 can need an explanation of demand and supply. It is synthetic practice only.

## Existing dataset: ASSET
Official page: https://huggingface.co/datasets/facebook/asset
Paper: https://aclanthology.org/2020.acl-main.424/
Published licence: CC BY-SA 4.0.
Licence explanation: https://creativecommons.org/licenses/by-sa/4.0/
Credit the creators and source, link the licence, identify changes, and use the same licence when sharing adapted dataset material. Licence checked against the dataset card on 12 October 2026. This does not promise zero legal or technical problems.

ASSET contains 2,000 validation and 359 test source sentences, with ten human simplifications per sentence. It has NO training split and NO Vocabulary/Syntactic/Conceptual labels. Use it for simplification evaluation. Its ratings configuration contains machine-generated outputs with human quality ratings; do not mistake those outputs for human reference rewrites. Keep its test split untouched until final evaluation.

## Download the full ASSET evaluation data free
Put download_asset.py in your project root (the folder with DATA).
Stop the server with Ctrl+C, then run these separately in your VS Code PowerShell terminal:

    .\.venv\Scripts\python.exe -m pip install datasets
    .\.venv\Scripts\python.exe download_asset.py

This downloads public dataset files. It does not call a paid inference API or start a cloud job. Download access and package installation need internet. It records the repository revision used.
Output: DATA/asset_evaluation/validation.jsonl, test.jsonl, and provenance.json.
These files do not plug directly into the project's support-category training command. No classifier has been trained by this download.

## Honest next research step
AI suggestions can support exploratory prototype training when labelled as AI-generated. Your review of visible AI suggestions is AI-assisted human review, not independent annotation. For an independently human-labelled evaluation set, use different examples without visible suggestions and make your own judgments. A single annotator can supply exploratory labels; report that limitation and do not claim inter-annotator agreement. The existing project may require code changes for a separate solo/AI-assisted workflow; do not bypass its gold-data guard or call this gold_v1.csv.

For today: review only the five examples. Do not train yet.
